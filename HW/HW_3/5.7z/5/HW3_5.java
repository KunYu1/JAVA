//javac *.java
//java Hw3_5
import javax.swing.JFrame;
import javax.swing.SwingUtilities;


public class HW3_5 {

	public static void main(String[] args) {
		MyFrame frame = new MyFrame();
		//System.out.println(i);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,300);
		frame.setVisible(true);
	}

}
