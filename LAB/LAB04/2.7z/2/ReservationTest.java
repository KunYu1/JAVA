import javax.swing.*;
import java.awt.*;

public class ReservationTest{
	public static void main (String args[]){
		Reservation e = new Reservation();
		e.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		e.setSize(3000,150);
		e.setVisible(true);
	}
}
		