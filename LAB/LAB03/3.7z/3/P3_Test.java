import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Dimension;

public class P3_Test
{  
   public static void main( String args[] ){
	   P3_JFrame w = new P3_JFrame();
       w.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
       w.setSize( 500, 500 );
       w.setVisible( true );
   }
}