// DrawStarsController.java
// Create a circle of stars using Polygons and Rotate transforms.
import java.security.SecureRandom;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.transform.Transform;

public class DrawStarsController {   
   @FXML private Pane pane;
   private static final SecureRandom random = new SecureRandom();
   
   public void initialize() {
    // points that define a five-pointed star shape
	
	
    Double[] points = {205.0,150.0, 217.0,186.0, 259.0,186.0, 
       223.0,204.0, 233.0,246.0, 205.0,222.0, 177.0,246.0, 187.0,204.0, 
       151.0,186.0, 193.0,186.0};
	 
	 
	//points for triangle
	Double x=200.0,y=150.0;
	Double[] tri_points = {0.0+x,0.0+y,50.0+x,0.0+y,25.0+x,43.25+y};
    
    // create 18 stars
    for (int count = 0; count < 10; ++count) {
       // create a new Polygon and copy existing points into it
       if(count%2 ==1){
		Polygon newStar = new Polygon();
		newStar.getPoints().addAll(points); 
		
		// create random Color and set as newStar's fill
		newStar.setStroke(Color.GREY);
		newStar.setFill(Color.rgb(random.nextInt(255), 
          random.nextInt(255), random.nextInt(255), 
          random.nextDouble())); 

       // apply a rotation to the shape
       newStar.getTransforms().add(
          Transform.rotate(count * 36+36, 150, 150));
       pane.getChildren().add(newStar);
	   }
	   
	   else{
			Polygon newTri = new Polygon();
			newTri.getPoints().addAll(tri_points); 

			// create random Color and set as newStar's fill
			newTri.setStroke(Color.GREY);
			newTri.setFill(Color.rgb(random.nextInt(255), 
			random.nextInt(255), random.nextInt(255), 
			random.nextDouble())); 
		
			// apply a rotation to the shape
			newTri.getTransforms().add(
			Transform.rotate(count * 36, 150, 150));
			pane.getChildren().add(newTri);
	   }
    } 
   }
	
}

/*************************************************************************
* (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/
